	<ul class="navigation">
        <li><a href="fluid-gallery.php" class='<?php echo $active1;?>'>Fluid gallery</a></li>
        <li><a href="gallery-clean.php" class='<?php echo $active2;?>'>Gallery clean</a></li>
        <li><a href="gallery-grid.php" class='<?php echo $active3;?>'>Gallery grid</a></li>
        <li><a href="thumbnail-gallery.php" class='<?php echo $active4;?>'>Thumbnail gallery</a></li>
    </ul>
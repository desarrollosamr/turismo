<footer class="footer">
      <div class="container">
        <p class="text-muted">Desarrollado por <a href="http://obedalvarado.pw/" target='_blank'>Obed Alvarado</a></p>
      </div>
</footer>
# Crea una Galería con Efecto Lightbox Fácilmente con Materialize CSS
### [Tutorial: https://www.youtube.com/watch?v=eSg2ni_a2pE](https://www.youtube.com/watch?v=eSg2ni_a2pE)

![Crea una Galería con Efecto Lightbox Fácilmente con Materialize CSS](https://raw.githubusercontent.com/falconmasters/lightbox-materialize/master/img/thumb.png)

Por: [FalconMasters](http://www.falconmasters.com)